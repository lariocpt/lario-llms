#!/usr/bin/env python3
import os
import sys
import argparse
import logging

# ==========================================
# Unified PyTorch ROCm Compatibility Layer
# ==========================================
import importlib.metadata
orig_version = importlib.metadata.version
def mock_version(package_name):
    if package_name.lower() == 'torch':
        return '2.4.0'
    return orig_version(package_name)
importlib.metadata.version = mock_version

import torch
torch.__version__ = "2.4.0"

# Mock missing distributed tensor and codecarbon modules
from unittest.mock import MagicMock
import types
try:
    import torch.distributed
    mock_tensor = types.ModuleType('torch.distributed.tensor')
    mock_tensor.device_mesh = MagicMock()
    torch.distributed.tensor = mock_tensor
    sys.modules['torch.distributed.tensor'] = mock_tensor
    sys.modules['torch.distributed.tensor.device_mesh'] = mock_tensor.device_mesh
except Exception:
    sys.modules['torch.distributed.tensor'] = MagicMock()
    sys.modules['torch.distributed.tensor.device_mesh'] = MagicMock()

# Polyfills for older PyTorch runtimes
import torch.amp
if not hasattr(torch.amp, 'GradScaler'):
    import torch.cuda.amp
    torch.amp.GradScaler = torch.cuda.amp.GradScaler

import torch.library
if not hasattr(torch.library, 'custom_op'):
    def dummy_custom_op(*args, **kwargs):
        def decorator(func): return func
        return decorator
    torch.library.custom_op = dummy_custom_op
if not hasattr(torch.library, 'register_fake'):
    def dummy_register_fake(*args, **kwargs):
        def decorator(func): return func
        return decorator
    torch.library.register_fake = dummy_register_fake
if not hasattr(torch.library, 'register_autograd'):
    def dummy_register_autograd(*args, **kwargs):
        def decorator(func): return func
        return decorator
    torch.library.register_autograd = dummy_register_autograd

if not hasattr(torch, 'uint16'): torch.uint16 = torch.int16
if not hasattr(torch, 'uint32'): torch.uint32 = torch.int32
if not hasattr(torch, 'uint64'): torch.uint64 = torch.int64

if not hasattr(torch, 'get_default_device'):
    torch.get_default_device = lambda: torch.device('cpu')

import torch.compiler
if not hasattr(torch.compiler, 'is_compiling'):
    torch.compiler.is_compiling = lambda: False

import torch.utils._pytree as torch_pytree
if not hasattr(torch_pytree, 'register_pytree_node'):
    torch_pytree.register_pytree_node = lambda typ, flat, unflat, serialized_type_name=None: torch_pytree._register_pytree_node(typ, flat, unflat)

# Bypass CVE-2025-32434 check which requires torch >= 2.6 for torch.load
import transformers
transformers.utils.import_utils.check_torch_load_is_safe = lambda: None
transformers.utils.check_torch_load_is_safe = lambda: None
transformers.modeling_utils.check_torch_load_is_safe = lambda: None
# ==========================================

import chromadb
from sentence_transformers import SentenceTransformer

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("ingest_repo")

# Supported file extensions for document ingestion
CODE_EXTENSIONS = {
    ".py", ".json", ".md", ".txt", ".csv", ".xlsx", ".pdf"
}

# Directories and files to ignore during walk
IGNORE_DIRS = {
    ".git", "node_modules", "dist", "build", ".next", ".cache",
    "__pycache__", "venv", ".venv", "chroma-data", "bifrost"
}

IGNORE_FILES = {
    "package-lock.json", "pnpm-lock.yaml", "yarn.lock", "bun.lockb",
    ".DS_Store"
}

def chunk_text(text, max_chars=1200, overlap=200):
    chunks = []
    start = 0
    while start < len(text):
        end = start + max_chars
        chunk = text[start:end]
        chunks.append((start, end, chunk))
        start += max_chars - overlap
    return chunks

def extract_text(file_path, ext):
    if ext.lower() == ".pdf":
        try:
            import PyPDF2
            with open(file_path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                return "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
        except Exception as e:
            logger.warning(f"Failed to read PDF {file_path}: {e}")
            return ""
    elif ext.lower() in [".xlsx", ".csv"]:
        try:
            import pandas as pd
            if ext.lower() == ".csv":
                df = pd.read_csv(file_path)
            else:
                df = pd.read_excel(file_path)
            return df.to_string()
        except Exception as e:
            logger.warning(f"Failed to read spreadsheet {file_path}: {e}")
            return ""
    else:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

def process_file(file_path, rel_path, documents, ids, metadatas, collection_name, chunk_size, overlap):
    """Read, chunk, and stage one file for ingestion. Returns True if chunks were added."""
    _, ext = os.path.splitext(file_path)
    try:
        content = extract_text(file_path, ext)
    except Exception as ex:
        logger.warning(f"Could not extract text from {rel_path}: {ex}")
        return False

    if not content or not content.strip():
        return False

    chunks = chunk_text(content, max_chars=chunk_size, overlap=overlap)
    logger.info(f"Processing {rel_path} ({len(chunks)} chunks)...")
    file_name = os.path.basename(file_path)
    for idx, (start, end, chunk_data) in enumerate(chunks):
        doc_id = f"{collection_name}-{rel_path.replace('/', '_').replace('.', '_')}-chunk{idx}"
        documents.append(chunk_data)
        ids.append(doc_id)
        metadatas.append({
            "rel_path": rel_path,
            "file_name": file_name,
            "chunk_index": idx,
            "start_char": start,
            "end_char": end,
            "extension": ext or "txt",
        })
    return True

def main():
    parser = argparse.ArgumentParser(description="Pseudo-train/Ingest active code repositories into local ChromaDB for RAG.")
    parser.add_argument("--repo-path", required=True, help="Absolute path to a repository directory OR a single file to ingest")
    parser.add_argument("--collection", default="my-repos", help="Name of the ChromaDB collection (default: my-repos)")
    parser.add_argument("--host", default="localhost", help="ChromaDB Host address (default: localhost)")
    parser.add_argument("--port", type=int, default=8000, help="ChromaDB Port (default: 8000)")
    parser.add_argument("--chunk-size", type=int, default=1200, help="Maximum characters per chunk (default: 1200)")
    parser.add_argument("--overlap", type=int, default=200, help="Character overlap between chunks (default: 200)")
    
    args = parser.parse_args()
    
    repo_path = os.path.abspath(args.repo_path)
    if not os.path.exists(repo_path):
        logger.error(f"Repository path does not exist: {repo_path}")
        sys.exit(1)
        
    logger.info(f"Connecting to ChromaDB HttpClient at {args.host}:{args.port}...")
    try:
        chroma_client = chromadb.HttpClient(host=args.host, port=args.port)
        # Attempt to get or create collection
        try:
            collection = chroma_client.get_collection(args.collection)
            logger.info(f"Using existing collection '{args.collection}'")
        except Exception:
            collection = chroma_client.create_collection(args.collection)
            logger.info(f"Created new collection '{args.collection}'")
    except Exception as e:
        logger.error(f"Failed to connect to ChromaDB: {e}")
        sys.exit(1)
        
    logger.info("Initializing sentence-transformers embedding model (BAAI/bge-m3)...")
    embedder = SentenceTransformer("BAAI/bge-m3")
    
    documents = []
    ids = []
    metadatas = []
    
    if os.path.isfile(repo_path):
        # Single explicit file: ingest it regardless of the extension/ignore lists
        # (the caller named it deliberately). rel_path is just the file name.
        logger.info(f"Ingesting single file: {repo_path}...")
        process_file(repo_path, os.path.basename(repo_path), documents, ids, metadatas,
                     args.collection, args.chunk_size, args.overlap)
    else:
        logger.info(f"Scanning directory: {repo_path}...")
        for root, dirs, files in os.walk(repo_path):
            # Modify dirs in-place to avoid walking down ignored directories
            dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]

            for file in files:
                if file in IGNORE_FILES:
                    continue

                _, ext = os.path.splitext(file)
                is_dockerfile = file.lower() == "dockerfile" or ext.lower() == ".dockerfile"

                if ext.lower() in CODE_EXTENSIONS or is_dockerfile:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, repo_path)
                    process_file(file_path, rel_path, documents, ids, metadatas,
                                 args.collection, args.chunk_size, args.overlap)

    if not documents:
        logger.info("No supported files found or no content to ingest.")
        return
        
    logger.info(f"Generating embeddings for {len(documents)} chunks (this uses your ROCm GPU if available)...")
    embeddings = embedder.encode(documents, show_progress_bar=True).tolist()
    
    logger.info(f"Ingesting {len(documents)} chunks into ChromaDB collection '{args.collection}'...")
    batch_size = 100
    for i in range(0, len(documents), batch_size):
        end_idx = min(i + batch_size, len(documents))
        collection.add(
            documents=documents[i:end_idx],
            embeddings=embeddings[i:end_idx],
            metadatas=metadatas[i:end_idx],
            ids=ids[i:end_idx]
        )
        logger.info(f"Ingested batch {i // batch_size + 1}/{-(-len(documents) // batch_size)}")
        
    logger.info("🎉 Ingestion complete! The model will now utilize these patterns in your RAG queries.")

if __name__ == "__main__":
    main()
